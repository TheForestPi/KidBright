Blockly.Msg.SHT31_GET_TEMPERATURE_TITLE = "อุณหภูมิ SHT31";
Blockly.Msg.SHT31_GET_TEMPERATURE_TOOLTIP = "อ่านค่าอุณหภูมิ SHT31";
Blockly.Msg.SHT31_GET_TEMPERATURE_HELPURL = "";

Blockly.Msg.SHT31_GET_HUMIDITY_TITLE = "ความชื้น SHT31";
Blockly.Msg.SHT31_GET_HUMIDITY_TOOLTIP = "อ่านค่าความชื้น SHT31";
Blockly.Msg.SHT31_GET_HUMIDITY_HELPURL = "";

Blockly.Msg.SHT31_IS_ERROR_TITLE = "การทำงานผิดพลาด SHT31";
Blockly.Msg.SHT31_IS_ERROR_TOOLTIP = "อ่านการทำงานผิดพลาดของ SHT31";
Blockly.Msg.SHT31_IS_ERROR_HELPURL = "";
